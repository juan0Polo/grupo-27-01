﻿namespace Proyectos.App.Persistencia;
public class Class1
{

}
