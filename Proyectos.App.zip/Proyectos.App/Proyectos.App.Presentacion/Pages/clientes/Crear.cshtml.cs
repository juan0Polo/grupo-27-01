using System;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

using Proyectos.App.Dominio.Entidades;

namespace Proyectos.App.Presentacion.clientes
{
       public class CrearModel : PageModel
    {
        [BindProperty]
        public Cliente client { get; set; }
        public void OnGet()
        {
        
        }

//     public async Task<ActionResult> OnPost()
//         {
//             if (!ModelState.IsValid) {
//                 return Page();
//             }
//             client.id = "";
//             client.nombre = "";
//             client.apellido = "";
//             client.tipoDocumento = "";
//             client.numeroDocumento = "";
//             client.rh = "";
//             client.motivoCita = "";
//             client.observaciones = "";
//            //aqui debcontext y guardar el registro
//             return RedirectToPage();
//         }
    }
}

