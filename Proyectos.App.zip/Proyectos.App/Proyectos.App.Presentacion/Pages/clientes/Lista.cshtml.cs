using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

using Proyectos.App.Dominio.Entidades;

using Microsoft.AspNetCore.Authorization;

namespace Proyectos.App.Presentacion.Pages.clientes
{
    public class ListaModel : PageModel
    {
        public IEnumerable<Cliente> listClientes { get; set; }
            public ListaModel(){
                cargarClientesTemporales();
            }
            
        public void OnGet()
        {
            cargarClientesTemporales();
        }

        public void cargarClientesTemporales(){
                listClientes = new List<Cliente>()
                {
                    new Cliente{id=1, nombre="JHOANNA", apellido="FERNANDEZ",tipoDocumento="cedula", numeroDocumento=1234, rh="o+", motivoCita="dolor de muela", observaciones="muela OK"},
                    new Cliente{id=2, nombre="ESTEBAN", apellido="IPIALES",tipoDocumento="cedula", numeroDocumento=1256, rh="o+", motivoCita="dolor de muela", observaciones="muela OK"},
                    new Cliente{id=3, nombre="EDGAR", apellido="MOLINA",tipoDocumento="cedula", numeroDocumento=1278, rh="o+", motivoCita="dolor de muela", observaciones="muela OK"},
                    new Cliente{id=4, nombre="JUAN", apellido="POLO",tipoDocumento="cedula", numeroDocumento=1290, rh="o+", motivoCita="dolor de muela", observaciones="muela OK"}
                };
            }
    }
}

