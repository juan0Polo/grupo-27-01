using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

using Proyectos.App.Dominio.Entidades;
namespace Proyectos.App.Presentacion.clientes
{
    public class DetalleModel : PageModel
    {
        [BindProperty]
        public Cliente client { get; set; }
        public void OnGet()
        {
            client = new Cliente{
                id = 1,
                nombre = "JUAN PABLO",
                apellido = "POLO MONTENEGRO",
                tipoDocumento = "Cedula de ciudadania",
                numeroDocumento = 12345,
                rh = "o+",
                motivoCita = "dolor de cabeza",
                observaciones = "el paciente sufre de migraña"
            };
        }
    }
}
