﻿namespace Proyectos.App.Presentacion;
public class Class1
{

}
