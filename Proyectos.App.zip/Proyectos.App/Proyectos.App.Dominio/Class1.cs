﻿namespace Proyectos.App.Dominio;
public class Class1
{

}
